-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Abr-2018 às 02:48
-- Versão do servidor: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--

--

-- --------------------------------------------------------

--
-- Estrutura da tabela `animals`
--

CREATE TABLE `animals` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagem` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `especie` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raca` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacao` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `animals`
--

INSERT INTO `animals` (`id`, `nome`, `imagem`, `idade`, `especie`, `raca`, `observacao`, `created_at`, `updated_at`) VALUES
(1, 'Marley', 'imagens/animais//imagem_7059.jpeg', '4', 'Canina', 'Beethoven', 'Saudável', '2018-04-23 05:50:25', '2018-04-24 02:25:47'),
(2, 'Buster', 'imagens/animais//imagem_6284.jpeg', '5', 'Canina', 'Bulldog', 'Saudável', '2018-04-23 06:06:41', '2018-04-23 06:06:41'),
(4, 'Bart', 'imagens/animais//imagem_7111.jpeg', '2', 'Felina', 'Siamês', NULL, '2018-04-23 07:37:49', '2018-04-23 16:38:34');

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacaos`
--

CREATE TABLE `doacaos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destino` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `doacaos`
--

INSERT INTO `doacaos` (`id`, `nome`, `cpf`, `telefone`, `tipo`, `quantidade`, `destino`, `created_at`, `updated_at`) VALUES
(1, 'Maria Oliveira', '458.475.236.47', '(16) 3548-4569', 'Ração', '10 Kg', 'Todos os animais', '2018-04-23 20:54:59', '2018-04-24 03:35:06'),
(2, 'Pedro Gouveia', '458.475.236.47', '(16) 3254-8965', 'Medicamento', '2 Caixas', 'Buster', '2018-04-23 21:02:36', '2018-04-23 21:02:36');

-- --------------------------------------------------------

--
-- Estrutura da tabela `historicos`
--

CREATE TABLE `historicos` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_animal` int(11) NOT NULL,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `animal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `veterinario` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `historicos`
--

INSERT INTO `historicos` (`id`, `id_animal`, `data`, `animal`, `veterinario`, `observacao`, `created_at`, `updated_at`) VALUES
(2, 1, '23/04/2018', 'Marley', 'João Silva', 'Saudável', '2018-04-23 23:30:09', '2018-04-23 23:30:09'),
(3, 1, '23/04/2018', 'Marley', 'João Silva', 'Saudável', '2018-04-23 23:34:46', '2018-04-23 23:34:46'),
(7, 2, '23/04/2018', 'Buster', 'Gabriel Dias', 'Saudável', '2018-04-24 00:02:57', '2018-04-24 00:02:57'),
(8, 1, '23/04/2018', 'Marley', 'Gabriel Dias', 'Estável', '2018-04-24 01:10:18', '2018-04-24 01:10:18'),
(9, 4, '24/04/2018', 'Bart', 'João Silva', 'Estável', '2018-04-24 19:28:13', '2018-04-24 19:28:13'),
(10, 2, '25/04/2018', 'Buster', 'João Silva', 'Estável', '2018-04-25 15:47:20', '2018-04-25 15:47:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_04_23_012613_create_animals_table', 1),
(4, '2018_04_23_125605_create_veterinarios_table', 2),
(5, '2018_04_23_153222_create_doacaos_table', 3),
(7, '2018_04_23_192516_create_historicos_table', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin@admin.com', '$2y$10$ysAmbIIusW3MbzyEiBuf6eQjHwwQ0wviGaq6HW01IH1uiSPb2Re8S', 'EK8QwdiY227YbkP5su9M4AS2JRv98nWKMAE1VBXdEHUTYi6NxuK5bp6zOaYm', '2018-04-24 04:44:43', '2018-04-24 04:44:43'),
(4, 'Teste', 'teste@teste.com', '$2y$10$mz79PeSddvY9.YtsMzOy8.UGoG.2GMSk2tWDf0QMBZq0dkKRC3kUO', '5iFOblNg3oOYfn30IWt6gpt9EYIZWyea8GV2baESw2ktffb3y2GomEc6nzj3', '2018-04-24 06:38:52', '2018-04-25 20:13:41');

-- --------------------------------------------------------

--
-- Estrutura da tabela `veterinarios`
--

CREATE TABLE `veterinarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crv` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rua` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `veterinarios`
--

INSERT INTO `veterinarios` (`id`, `nome`, `telefone`, `crv`, `cep`, `rua`, `cidade`, `estado`, `created_at`, `updated_at`) VALUES
(1, 'João Silva', '(16) 3333-5546', '45248268252', '14800-409', 'Rua 9 de Julho, 276', 'Araraquara', 'SP', '2018-04-23 16:25:04', '2018-04-24 20:47:56'),
(3, 'Gabriel Dias', '(16) 99542-5252', '42986325544', '14800-350', 'Rua Voluntários da Pátria, 45', 'Araraquara', 'SP', '2018-04-23 22:39:56', '2018-04-24 20:49:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doacaos`
--
ALTER TABLE `doacaos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `historicos`
--
ALTER TABLE `historicos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `veterinarios`
--
ALTER TABLE `veterinarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `animals`
--
ALTER TABLE `animals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doacaos`
--
ALTER TABLE `doacaos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `historicos`
--
ALTER TABLE `historicos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `veterinarios`
--
ALTER TABLE `veterinarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
